/**
* (c) 2016 Highsoft AS
* Authors: Lars A. V. Cabrera
*
* License: www.highcharts.com/license
*/
'use strict';
// import H from '../parts/Globals.js';
import 'grid-axis.js';
import '../modules/xrange.src.js';
